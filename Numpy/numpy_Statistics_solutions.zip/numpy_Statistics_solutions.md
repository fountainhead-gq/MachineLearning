
# Statistics


```python
import numpy as np
```


```python
np.__version__
```




    '1.11.3'



## Order statistics

Q1. Return the minimum value of x along the second axis.


```python
x = np.arange(4).reshape((2, 2))
print("x=\n", x)
print("ans=\n", np.amin(x, 1))
```

    x=
     [[0 1]
     [2 3]]
    ans=
     [0 2]
    

Q2. Return the maximum value of x along the second axis. Reduce the second axis to the dimension with size one.


```python
x = np.arange(4).reshape((2, 2))
print("x=\n", x)
print("ans=\n", np.amax(x, 1, keepdims=True))
```

    x=
     [[0 1]
     [2 3]]
    ans=
     [[1]
     [3]]
    

Q3. Calcuate the difference between the maximum and the minimum of x along the second axis.


```python
x = np.arange(10).reshape((2, 5))
print("x=\n", x)

out1 = np.ptp(x, 1)
out2 = np.amax(x, 1) - np.amin(x, 1)

print("ans=\n", out1)
print(out2)

```

    x=
     [[0 1 2 3 4]
     [5 6 7 8 9]]
    ans=
     [4 4]
    [4 4]
    

Q4. Compute the 75th percentile of x along the second axis.


```python
x = np.arange(1, 11).reshape((2, 5))
print("x=\n", x)

print("ans=\n", np.percentile(x, 75, 1))
```

    x=
     [[ 1  2  3  4  5]
     [ 6  7  8  9 10]]
    ans=
     [ 4.  9.]
    

## Averages and variances

Q5. Compute the median of flattened x.


```python
x = np.arange(1, 10).reshape((3, 3))
print("x=\n", x)

print("ans=\n", np.median(x))
```

    x=
     [[1 2 3]
     [4 5 6]
     [7 8 9]]
    ans=
     5.0
    

Q6. Compute the weighted average of x.


```python
x = np.arange(5)
weights = np.arange(1, 6)

out1 = np.average(x, weights=weights)
out2 = (x*(weights/weights.sum())).sum()
assert np.allclose(out1, out2)
print(out1)
print(out2)
```

    2.66666666667
    2.66666666667
    

Q7. Compute the mean, standard deviation, and variance of x along the second axis.


```python
x = np.arange(5)
print("x=\n",x)

out1 = np.mean(x)
out2 = np.average(x)
print("mean=\n", out1)
print("average=\n", out2)

out3 = np.std(x)
out4 = np.sqrt(np.mean((x - np.mean(x)) ** 2 ))

print("std=\n", out3)
print(out4)

out5 = np.var(x)
out6 = np.mean((x - np.mean(x)) ** 2 )

print("variance=\n", out5)
print(out6)

```

    x=
     [0 1 2 3 4]
    mean=
     2.0
    average=
     2.0
    std=
     1.41421356237
    1.41421356237
    variance=
     2.0
    2.0
    

## Correlating

Q8. Compute the covariance matrix of x and y.


```python
x = np.array([0, 1, 2])
y = np.array([2, 1, 0])

print("ans=\n", np.cov(x, y))
```

    ans=
     [[ 1. -1.]
     [-1.  1.]]
    

Q9. In the above covariance matrix, what does the -1 mean?

It means `x` and `y` correlate perfectly in opposite directions.

Q10. Compute Pearson product-moment correlation coefficients of x and y.


```python
x = np.array([0, 1, 3])
y = np.array([2, 4, 5])
print("ans=\n", np.corrcoef(x, y))
```

    ans=
     [[ 1.          0.92857143]
     [ 0.92857143  1.        ]]
    

Q11. Compute cross-correlation of x and y.


```python
x = np.array([0, 1, 3])
y = np.array([2, 4, 5])

print("ans=\n", np.correlate(x, y))
```

    ans=
     [19]
    

## Histograms

Q12. Compute the histogram of x against the bins.


```python
x = np.array([0.5, 0.7, 1.0, 1.2, 1.3, 2.1])
bins = np.array([0, 1, 2, 3])
print("ans=\n", np.histogram(x, bins))

import matplotlib.pyplot as plt
%matplotlib inline
plt.hist(x, bins=bins)
plt.show()
```

    ans=
     (array([2, 3, 1], dtype=int64), array([0, 1, 2, 3]))
    


![png](output_30_1.png)


Q13. Compute the 2d histogram of x and y.


```python
xedges = [0, 1, 2, 3]
yedges = [0, 1, 2, 3, 4]
x = np.array([0, 0.1, 0.2, 1., 1.1, 2., 2.1])
y = np.array([0, 0.1, 0.2, 1., 1.1, 2., 3.3])
H, xedges, yedges = np.histogram2d(x, y, bins=(xedges, yedges))
print("ans=\n", H)

plt.scatter(x, y)
plt.grid()
```

    ans=
     [[ 3.  0.  0.  0.]
     [ 0.  2.  0.  0.]
     [ 0.  0.  1.  1.]]
    


![png](output_32_1.png)


Q14. Count number of occurrences of 0 through 7 in x.


```python
x = np.array([0, 1, 1, 3, 2, 1, 7])
print("ans=\n", np.bincount(x))
```

    ans=
     [1 3 1 1 0 0 0 1]
    

Q15. Return the indices of the bins to which each value in x belongs.


```python
x = np.array([0.2, 6.4, 3.0, 1.6])
bins = np.array([0.0, 1.0, 2.5, 4.0, 10.0])

print("ans=\n", np.digitize(x, bins))
```

    ans=
     [1 4 3 2]
    


```python

```
